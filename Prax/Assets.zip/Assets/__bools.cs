﻿using UnityEngine;
using System.Collections;

public class __bools : MonoBehaviour {

	//elbows
	public static bool left_hand_elbow = false;
	public static bool right_hand_elbow = false;
	//shoulders
	public static bool left_hand_shoulder = false;
	public static bool right_hand_shoulder = false;
	//wrists
	public static bool left_hand_wrist = false;
	public static bool right_hand_wrist = false;
	//head
	public static bool head = false;

	public static bool left_leg_foot = false;
	public static bool right_leg_foot = false;
	//knees
	public static bool left_leg_knees = false;
	public static bool right_leg_knees = false;
	//stomach
	public static bool stomach = false;
	//heart
	public static bool heart = false;



	public static void allFalse(){
		//elbows
		left_hand_elbow = false;
		right_hand_elbow = false;
		//shoulders
		left_hand_shoulder = false;
		right_hand_shoulder = false;
		//wrists
		left_hand_wrist = false;
		right_hand_wrist = false;
		//head
		head = false;
		//foot
		left_leg_foot = false;
		right_leg_foot = false;
		//knees
		left_leg_knees = false;
		right_leg_knees = false;
		//stomach
		stomach = false;
		//heart
		heart = false;
	}

	
	
}