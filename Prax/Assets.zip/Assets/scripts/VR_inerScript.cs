﻿using UnityEngine;
using System.Collections;

public class VR_inerScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void homeVR(){
		print ("hh");
		Application.LoadLevel ("main_body");
	}
}
