﻿using UnityEngine;
using System.Collections;

public class bodypartsdetection : MonoBehaviour {

	public GameObject Body;

	void Start () {
	
	}
	
	void Update () {
	
	}



}

